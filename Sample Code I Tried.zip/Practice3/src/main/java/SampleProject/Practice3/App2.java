package SampleProject.Practice3;

import SampleProject.Practice1.*;

/**
 * Hello world!
 *
 */
public class App2 
{
    public static void main( String[] args )
    {
        App app1=new App();
        app1.add();
        app1.sub();
        app1.mul();
    }
}
