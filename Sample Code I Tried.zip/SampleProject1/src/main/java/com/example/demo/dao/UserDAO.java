package com.example.demo.dao;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.model.User;

@Repository
public class UserDAO {
	
	@Autowired
	private SessionFactory sessionFactory; 
	
	
	public void save(Object obj) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(obj);
		session.getTransaction().commit();
		session.close();
	}
	
	public List<User> fetchAccounts() {
		Session session = sessionFactory.openSession();
		List<User> users=session.createQuery("from User").list();
		//Query qry = session.createQuery("from User");
		return users;
	}
	
		
}
