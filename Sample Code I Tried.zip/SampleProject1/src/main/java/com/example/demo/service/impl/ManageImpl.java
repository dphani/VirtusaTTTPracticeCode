package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.UserDAO;
import com.example.demo.model.User;
import com.example.demo.service.Manage;

@Service
@Transactional
public class ManageImpl implements Manage {
	
	@Autowired
	private UserDAO userss;

	@Override
	public void saveAccount(User usr) {
		// TODO Auto-generated method stub
		userss.save(usr);
	}

	@Override
	public List<User> fetchAccounts() {
		// TODO Auto-generated method stub
		return userss.fetchAccounts();
	}

}
