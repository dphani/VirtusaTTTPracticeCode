package com.example.demo.controller;

abstract public class BaseController {

}
