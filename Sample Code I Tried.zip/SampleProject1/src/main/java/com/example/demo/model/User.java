package com.example.demo.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Userdet")
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int id;
	
	public String uname;
	
	public String branch;
	
	public String College;
	
	private List<User> Ulist;

	public int getId() {
		return id;
	}

	public List<User> getUlist() {
		return Ulist;
	}

	public void setUlist(List<User> ulist) {
		Ulist = ulist;
	}

	public void setId(int id) {
		this.id = id;
	}
	@Column(name="UserName")
	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}
	@Column(name="Branch")
	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}
	@Column(name="College")
	public String getCollege() {
		return College;
	}

	public void setCollege(String college) {
		College = college;
	}
	
	public User() {
		
	}
	public User(String uname) {
		this.uname=uname;
	}
	
	
	@Override
	public String toString() {
		return "User [id=" + id + ", UserName=" + uname + ", Branch=" + branch + ", College=" + College + "]";
	}

}
