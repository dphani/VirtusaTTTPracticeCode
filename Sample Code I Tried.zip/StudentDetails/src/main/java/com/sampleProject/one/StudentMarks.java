package com.sampleProject.one;

public interface StudentMarks {
	void total();
	void average();

}
