package com.sampleProject.one;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Report {

	public static void main(String[] args) {
		
		ApplicationContext cnn=new ClassPathXmlApplicationContext("Bean.xml");
		System.out.println("Success");
		StudentOne std1=(StudentOne)cnn.getBean("student1");
		std1.total();
		std1.average();

	}

}
