package com.sampleProject.one;

public class StudentOne implements StudentMarks {
	
	
	public StudentOne() {
		System.out.println("StudentOne Report:::");
	}

	public int student1=76, student2=56,student3=89;
	public int sum;
	public float percentage;
	
	

	public void total() {
		// TODO Auto-generated method stub
		sum=student1+student2+student3;
		System.out.println("Student One Total:"+sum);
	}

	public void average() {
		// TODO Auto-generated method stub
		percentage=((float)sum/300)*100;
		System.out.println("Student One Percentage:"+percentage);
	}

}
