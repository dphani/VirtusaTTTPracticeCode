package com.sampleProject.one;

public class StudentTwo implements StudentMarks {

	public int student1=52, student2=86,student3=69;
	public int sum;
	public float percentage;

	public void total() {
		// TODO Auto-generated method stub
		sum=student1+student2+student3;
		System.out.println("Student Two Total:"+sum);
	}

	public void average() {
		// TODO Auto-generated method stub
		percentage=((float)sum/300)*100;
		System.out.println("Student Two Percentage:"+percentage);
	}
}
