package SampleProject.Practice1;

/**
 * Hello world!
 *
 */
public class App 
{
	int a=30,b=20,c;
    public void add()
    {
    	c=a+b;
    	System.out.print( "\nThe Sum is"+c );
    }
    public void sub()
    {
    	c=a+b;
    	System.out.print( "\nThe Difference is"+c );
    }
    public void mul()
    {
    	c=a*b;
    	System.out.print( "\nThe Product is"+c );
    }
}
