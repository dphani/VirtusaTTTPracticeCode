package com.virtusa.ttt.bean;

import java.util.ArrayList;
import java.util.List;

public class CustomerServiceImpl implements CustomerService {

	public void doSomething() {
		// TODO Auto-generated method stub
		List<String> lstName = new ArrayList<String>();
		lstName.add("Do SomeThing::1");
		lstName.add("Do SomeThing::2");
		System.out.println("Method1=" + lstName);
	}

	public String doReturnSomething() {
		// TODO Auto-generated method stub
		List<String> lstName = new ArrayList<String>();
		lstName.add("Do Return SomeThing::1");
		lstName.add("Do Return SomeThing::2");
		System.out.println("Method1=" + lstName);
		return lstName.toString();
	}

}
