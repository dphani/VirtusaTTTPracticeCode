package com.virtusa.ttt.bean;

public interface CustomerService {
	public void doSomething();
	
	public String doReturnSomething();
}
