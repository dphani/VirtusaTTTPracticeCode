package com.virtusa.ttt.myapp.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.ttt.myapp.model.Account;
import com.virtusa.ttt.myapp.model.AccountStatements;
import com.virtusa.ttt.myapp.service.AccountManager;

@RestController
public class MyController extends BaseController {
	
	@Autowired
	private AccountManager accountService;
	
	@PostMapping(value="/create/accout", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Account> saveRealAccount(@RequestBody Account act) {
		accountService.saveAccount(act);
		
		Account account = accountService.fetchAccountByAccountNumber(act.getAccoutNumber());
		
		return new ResponseEntity<Account>(account,HttpStatus.OK);
	}
	
	
	
	@GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public String saveAccount(@PathVariable(name ="id") int id) {
		Account act1 = new Account();
		act1.setAccoutNumber("1234-5678-0000");
		act1.setBalance(5000);
		act1.setBranchCode("danavaiipet");
		act1.setFirstname("Kumar" + id);
		
		Account act2 = new Account();
		act2.setAccoutNumber("8976-5678-0000");
		act2.setBalance(2000);
		act2.setBranchCode("Tilak Road");
		act2.setFirstname("Phani" + id);
		
		AccountStatements actstmts1 = new AccountStatements();
		actstmts1.setAmount(1000);
		actstmts1.setDescription("Salary Credit");
		actstmts1.setTxnType("cr");
		actstmts1.setType("SALCREDIT");
		
		AccountStatements actstmts2 = new AccountStatements();
		actstmts2.setAmount(2000);
		actstmts2.setDescription("InVoice Credit");
		actstmts2.setTxnType("cr");
		actstmts2.setType("InvoiceCREDIT");

		List<AccountStatements> lstStmts = new ArrayList<AccountStatements>();
		lstStmts.add(actstmts1);
		lstStmts.add(actstmts2);
		
		act1.setLstAccountsStatements(lstStmts);
		
		accountService.saveAccount(act1);
		accountService.saveAccount(act2);
		
		
		return "completed";
		
	}
	
	@GetMapping(value = "/accounts", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Account>> fetchAccounts() {
		List<Account>  accounts = accountService.fetchAccounts();
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
	@GetMapping(value = "/high", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Account>> fetchHighSalAccounts() {
		List<Account>  accounts = accountService.fetchAccountByHighSalary();
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
}
