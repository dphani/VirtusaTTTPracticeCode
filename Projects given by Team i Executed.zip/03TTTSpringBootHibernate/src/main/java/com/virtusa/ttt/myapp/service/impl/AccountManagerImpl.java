package com.virtusa.ttt.myapp.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.ttt.myapp.dao.AccountDAOImpl;
import com.virtusa.ttt.myapp.model.Account;
import com.virtusa.ttt.myapp.service.AccountManager;

@Service
@Transactional
public class AccountManagerImpl implements AccountManager {

	@Autowired
	private AccountDAOImpl repo;

	@Override
	public List<Account> fetchAccounts() {
		// TODO Auto-generated method stub
		return repo.fetchAccounts();
	}

	@Override
	public void saveAccount(Account act) {
		// TODO Auto-generated method stub
		repo.save(act);
	}

	@Override
	public Account fetchAccountByAccountNumber(String accountNumber) {
		List<Account> lstAccoutns = repo.fetchAccountByAccountNumber(accountNumber);
		return lstAccoutns.get(0);
	}

	@Override
	public List<Account> fetchAccountByHighSalary() {
		// TODO Auto-generated method stub
		return repo.fetchAccountByHighSalary2();
	}

}
