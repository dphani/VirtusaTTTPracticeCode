package com.virtusa.ttt.myapp.dao;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.ttt.myapp.model.Account;

@Repository
public class AccountDAOImpl {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void save(Object obj) {
		Session session = sessionFactory.getCurrentSession();
		session.save(obj);
	}
	
	public List<Account> fetchAccounts() {
		Session session = sessionFactory.getCurrentSession();
		Query qry = session.createQuery("from Account");
		return qry.list();
	}
	
	
	public List<Account> fetchAccountByAccountNumber(String accountNumber) {
		Session session = sessionFactory.getCurrentSession();
		Query qry = session.createQuery("from Account a where a.accoutNumber=:acctnum");
		qry.setString("acctnum", accountNumber);
		return qry.list();
		
		 

		
	}
	
	public List<Account> fetchAccountByHighSalary() {
		Session session = sessionFactory.getCurrentSession();
		Query qry = session.getNamedQuery("@HQL_GET_ALL_ACCOUNT");
		return qry.list();
	}
	
	public List<Account> fetchAccountByHighSalary2() {
		Session session = sessionFactory.getCurrentSession();
		Criteria crit = session.createCriteria(Account.class);
		crit.add(Restrictions.gt("balance",5000));//salary is the propertyname  
		return crit.list();
	}
	
	
	
	
}
