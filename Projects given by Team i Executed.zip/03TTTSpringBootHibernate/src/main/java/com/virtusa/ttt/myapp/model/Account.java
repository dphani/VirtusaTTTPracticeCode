package com.virtusa.ttt.myapp.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GeneratorType;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.lang.NonNull;

@Entity
@Table(name = "tbl_account")
@NamedQueries({ @NamedQuery(name = "@HQL_GET_ALL_ACCOUNT", query = "from Account where balance>5000") })
public class Account extends BaseEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int id;
	
	@Column(name = "acctnum")
	public String accoutNumber;
	
	public int balance;
	
	public String firstname;
	
	public String branchCode;
	
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<AccountStatements> lstAccountsStatements;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccoutNumber() {
		return accoutNumber;
	}

	public void setAccoutNumber(String accoutNumber) {
		this.accoutNumber = accoutNumber;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public List<AccountStatements> getLstAccountsStatements() {
		return lstAccountsStatements;
	}

	public void setLstAccountsStatements(List<AccountStatements> lstAccountsStatements) {
		this.lstAccountsStatements = lstAccountsStatements;
	}
	
}
