package com.virtusa.ttt.myapp.controller;

abstract public class BaseController {

}
