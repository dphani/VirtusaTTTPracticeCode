package com.virtusa.ttt.myapp.dao;

public class BaseDAO {

}
