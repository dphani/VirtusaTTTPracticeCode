package com.virtusa.ttt.myapp.model;

import java.io.Serializable;

public class BaseEntity implements Serializable{

}
