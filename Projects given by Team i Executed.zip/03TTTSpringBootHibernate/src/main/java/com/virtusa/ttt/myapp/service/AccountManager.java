package com.virtusa.ttt.myapp.service;

import java.util.List;

import com.virtusa.ttt.myapp.model.Account;

public interface AccountManager {
	public void saveAccount(Account act);
	public List<Account> fetchAccounts();
	Account fetchAccountByAccountNumber(String accountNumber);
	public List<Account> fetchAccountByHighSalary();
}
